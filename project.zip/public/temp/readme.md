in this folder files like pdf images videos etc will save for temporary just to have an extra attempt to upload it is temporary
